export const getStoredUrls = () => {
  return JSON.parse(localStorage.getItem("urls")) || {};
};

export const storeUrl = (shortcode, data) => {
  const urls = getStoredUrls();
  urls[shortcode] = data;
  localStorage.setItem("urls", JSON.stringify(urls));
};