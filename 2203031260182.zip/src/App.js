import React from "react";
import { Routes, Route } from "react-router-dom";
import URLShortener from "./components/URLShortener";
import Statistics from "./components/Statistics";
import RedirectHandler from "./components/RedirectHandler";

function App() {
  return (
    <Routes>
      <Route path="/" element={<URLShortener />} />
      <Route path="/stats" element={<Statistics />} />
      <Route path="/:shortcode" element={<RedirectHandler />} />
    </Routes>
  );
}

export default App;