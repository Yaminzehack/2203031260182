import React from "react";

const URLShortener = () => {
  return (
    <div>
      <h2>URL Shortener Page</h2>
      {/* Form will go here */}
    </div>
  );
};

export default URLShortener;