import React, { useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";

const RedirectHandler = () => {
  const { shortcode } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    const urls = JSON.parse(localStorage.getItem("urls")) || {};
    if (urls[shortcode]) {
      window.location.href = urls[shortcode].originalUrl;
    } else {
      navigate("/");
    }
  }, [shortcode, navigate]);

  return null;
};

export default RedirectHandler;