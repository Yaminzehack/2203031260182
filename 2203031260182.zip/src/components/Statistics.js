import React from "react";

const Statistics = () => {
  return (
    <div>
      <h2>Statistics Page</h2>
      {/* Stats view will go here */}
    </div>
  );
};

export default Statistics;